module.exports = async (req, reply) => {
  return {
    message: 'Task controllers'
  }
}