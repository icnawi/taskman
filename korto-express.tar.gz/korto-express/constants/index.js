const message = 'Sorry, the page you are looking for could not be found.';

module.exports = {
  message
}
